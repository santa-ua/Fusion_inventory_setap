package
        setup;

use strict;
use warnings;
use parent qw(Exporter);

our @EXPORT = ('%setup');

our %setup = (
    datadir => "/usr/share/fusioninventory",
    libdir  => "/usr/share/fusioninventory/lib",
    vardir  => "/var/lib/fusioninventory-agent",
);

1;
