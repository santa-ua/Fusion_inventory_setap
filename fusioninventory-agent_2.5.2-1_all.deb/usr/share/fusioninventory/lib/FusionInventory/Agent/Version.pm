package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "2.5.2-1";
our $PROVIDER = "FusionInventory";
our $COMMENTS = [
    "Built by Teclib",
    "Build time: 2019-12-17-16h16"
];

1;

