package FusionInventory::Agent::Task::WakeOnLan::Version;

use strict;
use warnings;

use constant VERSION => "2.2";

1;
